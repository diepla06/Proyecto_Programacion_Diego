package Tema_1;

public class T1E5 {
    public static void main(String[] args) {
        System.out.println("Mi primer proyecto:"); ;
        double resultado = 24 % 5 ;
        System.out.println("24 % 5 = " + resultado);
        resultado = 7 / 2 + 2.5 ;
        System.out.println("7 / 2 + 2.5 = " + resultado);
        resultado = 10.8 / 2 + 2 ;
        System.out.println("10.8 / 2 + 2.5 = " + resultado);
        resultado = ( 4 + 6 ) * 3 + 2 * ( 5 - 1) ;
        System.out.println("4 + 6 * 3 + 2 * (5 - 1) = " + resultado);
        resultado = 5 / 2 + 17 % 3 ;
        System.out.println("5 / 2 + 17 % 3 = " + resultado);
        boolean bresultado = 7 >= 5 || 27 != 8 ;
        System.out.println("7 >= 5 OR 27 != 8 = " + bresultado);
        bresultado = (45 <= 7) || ! ( 5 >= 7 ) ;
        System.out.println("45 <= 7 OR NOT ( 5 >= 7 ) = " + bresultado);
        resultado = 27 % 4 + 15 / 4 ;
        System.out.println("27 % 4 + 15 % 4 = " + resultado);
        resultado = 37 / 4 * 4 - 2 ;
        System.out.println("37 / 4 * 4 - 2 = " + resultado);
        bresultado = (25 >= 7) && ! (7 <=2) ;
        System.out.println("25 >= 7 AND NOT (7 <=2) = " + bresultado);
        bresultado = ('H' < 'J') && ('9' != '7') ;
        System.out.println("('H' < 'J') AND ('9' <> '7') = " + bresultado);
        bresultado = 25 > 20 && 13 > 5;
        System.out.println("25 > 20 AND 13 > 5 = " + bresultado);
        bresultado = 10 + 4 < 15 - 3 || 2 * 5 + 1 > 14 - 2 * 2 ;
        System.out.println("10 + 4 < 15 - 3 OR 2 * 5 + 1 > 14 - 2 * 2) = " + bresultado);
        bresultado = 4 * 2 <= 8 || 2 * 2 < 5 && 4 > 3 + 1 ;
        System.out.println("4 * 2 <= 8 OR 2 * 2 < 5 AND 4 > 3 + 1 = " + bresultado );
        bresultado = 10 <= 2 * 5 && 3 < 4 || ! (8>7) && 3 * 2 <= 4 * 2 - 1 ;
        System.out.println("10 <= 2 * 5 AND 3 < 4 OR NOT (8>7) AND 3 * 2 <= 4 * 2 - 1 = " + bresultado);




    }
}
